For help about how to use the program, run arss --help or visit the website at http://arss.sf.net. Feel free to e-mail me any question or suggestion.
